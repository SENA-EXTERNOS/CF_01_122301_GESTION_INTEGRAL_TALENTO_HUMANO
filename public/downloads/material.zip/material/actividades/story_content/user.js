function ExecuteScript(strId)
{
  switch (strId)
  {
      case "62ho9kKt3yR":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

